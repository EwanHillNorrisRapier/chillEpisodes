WORKBOOK INPUTS, AUGUST 2026: THE PRICING SHEETS

The row-level frames that the three pricing sheets of Chill_Structural_Segmentation_2026-09-07_TENURE-4.xlsx were built
from ('Renewal price grid', 'Pricing - offer levels', 'Pricing - offer bands'). They let the pack prove its table code
reproduces the workbook exactly, apart from the data movement a live run picks up.

  cd build
  python sc_wb_pricing.py --replay

rebuilds every table from these files with no pulls, writes ../outputs/workbook/replay/ and ties out against
reference/workbook_TENURE-4_2026-09-07_cells.csv. Result on 5 Oct 2026: 2,726 of 2,726 cells exact (counts identical,
largest money difference 6e-14, largest rate difference 1e-16, floating point only).

FILES (UTF-8, one header row, dates YYYY-MM-DD, blank = no value)

renewals.csv            260,136 rows, 33 MB. One row per Motor / Home / Van renewal due 1 Jul 2025 to 30 Jun 2026.
  code, due                   policy code and adjusted due date (the fact's LYPolicyRenewDateAdj), the pack's key
  product, risk_segment       Van on the van-age overlay
  paid, offer, ty_prem        LYEURGrossPremium, RenEURPremOffer, TYEURGrossPremium
  fee, comm                   LYEURFees, LYEURCommission (expiring term)
  ty_fee, ty_comm, ren_fee    TYEURFees, TYEURCommission (renewed term), RenEURFee (quoted fee)
  promo_amount                PromoCodeAmount (a promo is a value below zero)
  retained, unresolved        the four-signal retention, and unresolved = not retained with no lapse status
  tenure                      customer tenure in years at the month-end before the due month (6 decimals)
  offer_band_4wk, offer_band_52wk   the offer against trailing offers, '(no offer)' where none
  paid_band_4wk, paid_band_52wk     the expiring premium against trailing offers, '(no read)' where paid is zero

travel_annual.csv       45,988 rows, 2.6 MB. One row per annual multi-trip travel expiry in the same year.
  code, due, paid, fee, comm, retained (45-day basis), paid_band_4wk, paid_band_52wk (against the annual travel market),
  renewed_premium, renewed_fee, renewed_comm (the successor policy, blank where none was found)

single_trip_cohort.csv  48,234 rows, 2.4 MB. One row per customer of the single-trip cohort at 30 Jun 2025.
  scv (customer key, as in the pack's other reference files), group (8b or 8c), repurchased, repurchased_annual,
  last_premium, last_fee, last_comm (the last single-trip purchase before the anchor), spend (trailing-year single-trip
  premium), comeback_premium, comeback_fee, comeback_comm (the first purchase after the anchor)

WHERE THEY CAME FROM

make_inputs.py (beside this file) made them on 5 Oct 2026 from the original build's own caches and pickles in
Segmentation/build, pulled 7 to 12 Aug 2026 and not shipped with the pack: _mf_dues.pkl, _depth_events_fixed.pkl,
_offer_bands.pkl, offer_probe.csv, offer_probe_prioryr.csv, ty_fees_yr.csv, promo_probe.csv, yr_mkt_trav.csv,
trav_full.csv, trav_singles.csv, travel_comm_check.csv, depth_val_20250630.csv, home_tier.csv.

  The bands were cut by the pack's sc_wb_pricing.band() on the August reference. The offer bands equal the bands the
  workbook build saved (_offer_bands.pkl) on every one of the 260,136 rows, asserted in make_inputs.py.
  The annual travel rows come from sc_wb_pricing.travel_dues() on trav_full.csv (45,988 expiries, 20,237 retained).
  The single-trip cohort was made by the 12 Aug builder's own code (build_pricing_grid_0812.py), run verbatim. Its
  'last single-trip premium' takes the last row of an unstable sort, and 70 of the 8c customers bought two trips on their
  last date, so which trip counts depends on the input order and the library version. Run verbatim on the original
  files with numpy 2.2.6 and pandas 2.3.3, it returns the workbook's assignment exactly (8c bands 1,441 / 1,239 / 1,260,
  8b 14,853 / 14,798 / 14,475, asserted). The pack's live cohort() breaks those ties by date and policy code instead,
  which moves up to 4 of those customers between bands.

No personal data beyond policy codes and customer keys, which the pack's other reference files already carry.
