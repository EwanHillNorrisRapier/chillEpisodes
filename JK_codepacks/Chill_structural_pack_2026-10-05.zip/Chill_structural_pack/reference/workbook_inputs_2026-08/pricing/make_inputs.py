#!/usr/bin/env python3
"""Provenance: how the three replay files beside this script were made. Not part of the pack's run.

  python make_inputs.py

Reads the ORIGINAL workbook build's row-level caches and pickles (Segmentation/build/_cache and Segmentation/build/*.pkl,
pulled 7 to 12 Aug 2026, not shipped with the pack) and writes the frames the pricing table code consumes:

  renewals.csv            the 260,136 Motor / Home / Van renewals of the workbook (_mf_dues.pkl, retention and tenure from
                          _depth_events_fixed.pkl, offer and renewed premium from offer_probe.csv, renewed fee from
                          ty_fees_yr.csv, promo and quoted fee from promo_probe.csv). Bands from sc_wb_pricing.band() on the
                          August reference (offer_probe_prioryr.csv + the year's offers + yr_mkt_trav.csv): the offer bands
                          equal the bands the workbook build saved (_offer_bands.pkl) on every row, asserted below
  travel_annual.csv       the 45,988 annual multi-trip expiries, sc_wb_pricing.travel_dues() on trav_full.csv with the
                          policytravel admin fee and expected commission from travel_comm_check.csv
  single_trip_cohort.csv  the 48,234 single-trip customers of the 30 Jun 2025 cohort, made by the 12 Aug builder's own code
                          (build_pricing_grid_0812.py, lines 674 to 723 and 769 to 773) run verbatim on its own caches. Its
                          'last single-trip premium' takes the last row of an unstable sort, which for the 70 customers with
                          two trips on their last date depends on the input order and the library: run here with numpy
                          2.2.6 and pandas 2.3.3 it gives the workbook's 8c split exactly (asserted below)
"""
import os, sys
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PACK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
ORIG = os.path.abspath(os.path.join(PACK, "..", "build")); CA = os.path.join(ORIG, "_cache")
sys.path.insert(0, os.path.join(PACK, "build"))
import sc_wb_pricing as W  # noqa: E402

# ---------------------------------------------------------------------------------------------------- renewals
MD = pd.read_pickle(os.path.join(ORIG, "_mf_dues.pkl")).reset_index(drop=True)
DE = pd.read_pickle(os.path.join(ORIG, "_depth_events_fixed.pkl")).reset_index(drop=True).iloc[:len(MD)]
OB = pd.read_pickle(os.path.join(ORIG, "_offer_bands.pkl")).reset_index(drop=True).iloc[:len(MD)]
assert (DE.code.values == MD.code.astype(str).str.strip().values).all() and (OB.code.values == DE.code.values).all()
R = pd.DataFrame({"code": MD.code.astype(str).str.strip(), "RenewalMonth": pd.to_datetime(MD.RenewalMonth),
                  "due": pd.to_datetime(MD.due_adj), "product": MD["product"], "risk_segment": MD.seg, "status": MD.status,
                  "paid": MD.ly_prem, "fee": MD.ly_fees, "comm": MD.ly_comm, "ty_comm": MD.ty_comm,
                  "ret": DE.ret.values.astype(float), "tenure": DE.tenure.values})
op = pd.read_csv(os.path.join(CA, "offer_probe.csv"), low_memory=False, parse_dates=["RenewalMonth"])
op["code"] = op.code.astype(str).str.strip()
R = R.merge(op.drop_duplicates(["code", "RenewalMonth"])[["code", "RenewalMonth", "offer", "ty_prem"]], on=["code", "RenewalMonth"], how="left")
ty = pd.read_csv(os.path.join(CA, "ty_fees_yr.csv"), parse_dates=["RenewalMonth"]); ty["code"] = ty.code.astype(str).str.strip()
R = R.merge(ty.drop_duplicates(["code", "RenewalMonth"]), on=["code", "RenewalMonth"], how="left")
pp = pd.read_csv(os.path.join(CA, "promo_probe.csv"), low_memory=False, parse_dates=["due_adj"]); pp["code"] = pp.code.astype(str).str.strip()
R = R.merge(pp[["code", "due_adj", "PromoCodeAmount", "ren_fee"]].rename(columns={"due_adj": "due", "PromoCodeAmount": "promo_amount"}),
            on=["code", "due"], how="left")
assert len(R) == 260_136
R["lost"] = 1 - R.ret
R["unres"] = (R.ret == 0) & ~R.status.isin(["Lapsed", "Lapsed for Transfer", "Cancelled", "Cancelled Mid Term"])
R["week"] = W._week(R.due)
tier = pd.read_csv(os.path.join(CA, "home_tier.csv")); tmap = dict(zip(tier.iloc[:, 0].astype(str).str.strip(), tier.iloc[:, 1]))
pr = pd.read_csv(os.path.join(CA, "offer_probe_prioryr.csv"), low_memory=False); pr["code"] = pr.code.astype(str).str.strip()
pr = pr[pr.offer > 0].copy()
pr["risk_segment"] = np.where(pr["product"] == "Motor", pr.band, np.where(pr["product"] == "Van", pr.age_band.map(W.O.van_seg), pr.code.map(tmap)))
prior = pr.dropna(subset=["risk_segment"]).assign(due=lambda z: pd.to_datetime(z.due_adj))[["product", "risk_segment", "due", "offer"]]
tm = pd.read_csv(os.path.join(CA, "yr_mkt_trav.csv"), parse_dates=["tx_date"])
market = pd.DataFrame({"product": "Travel", "risk_segment": W.AMT, "due": tm.tx_date, "price": tm.prem})

# ------------------------------------------------------------------------------------------------ annual travel
TF0 = pd.read_csv(os.path.join(CA, "trav_full.csv"), low_memory=False); TF0["code"] = TF0.code.astype(str).str.strip()
tc = pd.read_csv(os.path.join(CA, "travel_comm_check.csv"), low_memory=False); tc["code"] = tc.code.astype(str).str.strip()
tr = pd.DataFrame({"code": TF0.code, "client": TF0.client, "scv": TF0.scv, "status": TF0.status, "incept": TF0.incept,
                   "renew": TF0.renewdate, "cancel": TF0.cancel, "duration_days": TF0.ap_dur, "premium": TF0.prem, "fees": TF0.fees,
                   "void_flag": TF0.pt_void, "admin_fee": TF0.code.map(dict(zip(tc.code, tc.AdminFee))),
                   "exp_comm": TF0.code.map(dict(zip(tc.code, tc.exp_comm)))})
T = W.travel_dues(tr, "2026-06-30")
assert len(T) == 45_988 and int(T.ret.sum()) == 20_237
W.band(R, T, prior.rename(columns={"offer": "price"}), market)
for c in ("b4", "b52"):
    assert (R[c].replace("(no offer)", "No priced offer").values == OB[c].values).all(), c

# --------------------------------------------- single-trip cohort, verbatim from build_pricing_grid_0812.py
TF = pd.read_csv(os.path.join(CA, "trav_full.csv"), low_memory=False)
TF["code"] = TF.code.astype(str).str.strip()
TF["scv"] = pd.to_numeric(TF.scv, errors="coerce")
for _c in ("incept", "renewdate"):
    TF[_c] = pd.to_datetime(TF[_c], errors="coerce")
TF = TF[TF.scv.notna() & (TF.prem > 0) & (TF.pt_void.fillna(0) == 0)]
TS = pd.read_csv(os.path.join(CA, "trav_singles.csv"), parse_dates=["incept"])
_sc = set(TS.code.astype(str).str.strip())
TF["is_single"] = TF.code.isin(_sc) | (TF.ap_dur < 360)
_T0 = pd.Timestamp("2025-06-30")
_v0 = pd.read_csv(os.path.join(CA, "depth_val_20250630.csv"))
_core = set(_v0.loc[_v0.n_products_core > 0, "scv"])
_infann = set(TF.loc[(~TF.is_single) & (TF.incept <= _T0) & (TF.renewdate > _T0), "scv"].astype(int))
_w = TS[(TS.incept > _T0 - pd.Timedelta(days=365)) & (TS.incept <= _T0)]
_nst = _w.groupby("scv").size()
REP = pd.DataFrame({"scv": _nst.index.astype(int), "n": _nst.values})
REP = REP[~REP.scv.isin(_core) & ~REP.scv.isin(_infann)]
REP["grp"] = np.where(REP.n >= 2, "8c", "8b")
_rw = TF[(TF.incept > _T0) & (TF.incept <= _T0 + pd.Timedelta(days=365))]
REP["rep"] = REP.scv.isin(set(_rw.scv.astype(int)))
REP["rep_ann"] = REP.scv.isin(set(_rw.loc[~_rw.is_single, "scv"].astype(int)))
_wv = _w.copy()
_wv["code"] = _wv.code.astype(str).str.strip()
_wv = _wv.merge(TF[["code", "prem"]].drop_duplicates("code"), on="code", how="left")
_wv["scv_i"] = _wv.scv.astype(int)
_wv = _wv[_wv.scv_i.isin(set(REP.scv)) & (_wv.prem > 0)]
_last = _wv.sort_values("incept").groupby("scv_i").tail(1)
_last = _last.merge(tc[["code", "AdminFee", "exp_comm"]].drop_duplicates("code"), on="code", how="left")
REP = REP.merge(_last[["scv_i", "prem", "AdminFee", "exp_comm"]].rename(columns={"scv_i": "scv", "prem": "last_prem"}),
                on="scv", how="left")
REP["spend"] = REP.scv.map(_wv.groupby("scv_i").prem.sum())
_feemap, _commmap = dict(zip(tc.code, tc.AdminFee)), dict(zip(tc.code, tc.exp_comm))
_rw_f = _rw.sort_values("incept").groupby("scv").first()
REP["comeback"] = REP.scv.map(_rw_f.prem)
REP["comeback_fee"] = REP.scv.map(_rw_f.code.map(_feemap))
REP["comeback_comm"] = REP.scv.map(_rw_f.code.map(_commmap))
# ---- end verbatim
C = REP.rename(columns={"AdminFee": "last_fee", "exp_comm": "last_comm"})
ST = W.cohort_stats(C)
assert [ST["8c"]["bands"][b]["n"] for b in W.BANDS] == [1_441, 1_239, 1_260], "8c split differs from the workbook"
assert [ST["8b"]["bands"][b]["n"] for b in W.BANDS] == [14_853, 14_798, 14_475]

# ------------------------------------------------------------------------------------------------------- write
tf = lambda s: s.dt.strftime("%Y-%m-%d")  # noqa: E731
assert not ((R.tenure.round(6) < 1) != (R.tenure < 1)).any()
pd.DataFrame({
    "code": R.code, "due": tf(R.due), "product": R["product"], "risk_segment": R.risk_segment, "paid": R.paid, "offer": R.offer,
    "ty_prem": R.ty_prem, "fee": R.fee, "comm": R.comm, "ty_fee": R.ty_fee, "ty_comm": R.ty_comm, "ren_fee": R.ren_fee,
    "promo_amount": R.promo_amount, "retained": R.ret.astype(bool), "unresolved": R.unres.astype(bool),
    "tenure": R.tenure.round(6), "offer_band_4wk": R.b4, "offer_band_52wk": R.b52, "paid_band_4wk": R.pb4,
    "paid_band_52wk": R.pb52}).to_csv(os.path.join(HERE, "renewals.csv"), index=False, encoding="utf-8")
pd.DataFrame({
    "code": T.code, "due": tf(T.due), "paid": T.paid, "fee": T.fee, "comm": T.comm, "retained": T.ret.astype(bool),
    "paid_band_4wk": T.pb4, "paid_band_52wk": T.pb52, "renewed_premium": T.suc_prem, "renewed_fee": T.suc_fee,
    "renewed_comm": T.suc_comm}).to_csv(os.path.join(HERE, "travel_annual.csv"), index=False, encoding="utf-8")
pd.DataFrame({
    "scv": C.scv, "group": C.grp, "repurchased": C.rep, "repurchased_annual": C.rep_ann, "last_premium": C.last_prem,
    "last_fee": C.last_fee, "last_comm": C.last_comm, "spend": C.spend, "comeback_premium": C.comeback,
    "comeback_fee": C.comeback_fee, "comeback_comm": C.comeback_comm}).to_csv(
    os.path.join(HERE, "single_trip_cohort.csv"), index=False, encoding="utf-8")
print("written:", ", ".join(f"{f} {os.path.getsize(os.path.join(HERE, f)):,} bytes" for f in
                            ("renewals.csv", "travel_annual.csv", "single_trip_cohort.csv")))
