WORKBOOK INPUTS, AUGUST 2026: THE DEPTH AND TENURE SHEETS

What this folder is
The row-level inputs that the four depth and tenure sheets of Chill_Structural_Segmentation_2026-09-07_TENURE-4.xlsx were
built from ('Depth segmentation', 'Depth segmentation (ex-travel)', 'Depth x price crosstab', 'Tenure profile'), exported
from the original August 2026 build so the table code can be replayed without the lakehouse:

  python sc_wb_depth.py --replay ../reference/workbook_inputs_2026-08/depth

The replay runs the module's own depth cascade and every table on these two files and ties out against
reference/workbook_TENURE-4_2026-09-07_cells.csv: 2,803 of 2,803 cells exact (2,763 numbers and 40 data-driven labels and text
cells). A live run reads today's lakehouse, which has moved since August, so it does not tie out exactly. The replay is the
proof that the code does.

renewals.csv (306,124 rows: every renewal due 1 Jul 2025 to 30 Jun 2026)
  code, product, due        the policy and its renewal date (Motor / Home / Van 260,136, annual travel 45,988)
  scv                       the customer key (ads.finaleadmlink as read on 10 Aug 2026, the lowest key per code)
  paid, fee, comm           the expiring term's premium, fee and commission (renewals fact LYEURGrossPremium, LYEURFees,
                            LYEURCommission, travel the policy premium, Mapfre AdminFee and ExpectedCommission)
  retained                  1 if retained: the four-signal read for Motor / Home / Van, the 45-day successor read for travel
  offer_band_4wk,           the price band against the trailing 28 and 364 days of offers in the same product x risk segment
  offer_band_52wk           (travel bands the price charged against annual travel sales). (no offer) = no genuine offer
  keycare_term              1 if the renewing policy carried a KeyCare term dated to the month-end before the due month
  n_policies_raw,           the customer at the month-end before the due month: policies in force, core products, travel
  n_products_core,          policies in force (the seven-status SQL as-at read). Blank when the customer held nothing then
  n_travel_policies,        (the no-book row). tenure_years is the current continuous spell, as the SQL returned it (6
  tenure_years              decimals)
  has_annual_travel,        travel at that month-end: a priced, unvoided annual policy in force, a priced, unvoided single
  has_single_trip,          trip in force, and single trips incepted in the 365 days to it
  n_single_trips_12m
  holding_combination       for Portfolio renewals only: the product of every policy the customer held then, sorted

single_trip_cohort.csv (48,234 rows: the 8b / 8c supplementary rows)
  scv                       a customer who incepted a single trip in the year to 30 Jun 2025 and held neither a core product
                            nor a priced, unvoided annual travel policy on that date
  n_single_trips_12m        their single trips in that year (2 or more = group 8c, else 8b)
  group                     8b or 8c
  repurchased               1 if they incepted any priced, unvoided travel policy in the year after
  last_single_trip_premium  the premium of their last priced, unvoided single trip in the year (blank when none)
  single_trip_spend         the sum of their priced, unvoided single-trip premiums in the year

Where it came from
Exported on 5 Oct 2026 from the original build in Segmentation/build/: the labelled renewals of _depth_events_fixed.pkl
(policy, money, retention, customer key, built by rebuild_depth.py from _mf_dues.pkl and _mf_trav.pkl), the bands of
_offer_bands.pkl (rebuild_offer_bands.py), the holding combinations of _portfolio_combos.pkl, the month-end reads
_cache/depth_val_<date>.csv, the travel caches _cache/trav_full.csv and _cache/trav_singles.csv, and the KeyCare caches
_cache/rv_kciterm.csv and _cache/rv_kci.csv, read as the August builders read them. The single-trip cohort is the
construction of build_0819.py on the same caches. The cascade on these inputs reproduces the August depth labels of both
sheets on all 306,124 renewals.

Personal data: none beyond the policy codes and SCV keys the pack already ships in reference/. No names, addresses, dates of
birth or client codes.
