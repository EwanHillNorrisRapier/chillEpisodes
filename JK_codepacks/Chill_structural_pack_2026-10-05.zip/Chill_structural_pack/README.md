# Chill structural segmentation: build pack

Builds the two structural segmentation tables for any as-at date, straight from the Chill lakehouses, without the Fabric
notebook. Three stages, run by one command, ending in a validation report. A fourth stage (5 Oct 2026) rebuilds every number of
the TENURE-4 structural workbook and ties each one out against it: see 'The TENURE-4 workbook's numbers' below.

| Output | Grain | What it carries |
|---|---|---|
| `structural_customer_<date>.csv` | one row per SCV customer holding cover at the date | the five holdings axes (tenure, policy count, product breadth, add-on, payment), the eight **holdings segments** (July 2026 rules), the **depth tier** with its tenure sub-band (19 Aug 2026 cascade, four-year tenure boundary), income, and every input each rule read |
| `structural_policy_<date>.csv` | one row per policy in force at the date | product, pricing segment, premium, **pricing band** Low / Mid / High against the frozen cut-points, KeyCare term flag, income |
| `summary_<date>.txt` | | the counts |
| `workbook/<sheet>__<table>.csv`, `workbook/tieout_<anchor>.csv` | one csv per table of the workbook, laid out as on the sheet, and one row per number | the TENURE-4 workbook's tables rebuilt, and each number's workbook value, pack value and tie-out status |
| `offer_levels_<window>.csv` | one row per Motor / Home / Van renewal due in the twelve months to an anchor | the **offer levels**: the renewal offer banded Low / Mid / High against the trailing four weeks and the trailing 52 weeks of offers in the same product x risk segment, plus the same bands on the expiring premium, the offer-to-paid momentum, and the workbook's four-signal retention per renewal |

The customer table carries the depth tier twice: `depth_code` / `depth_tier` on the published rule, and
`depth_code_extravel` / `depth_tier_extravel` where travel counts for nothing in the holdings test (the workbook's second
depth sheet). These are the three sheets of the structural workbook at row level: 'Pricing - offer levels',
'Depth segmentation' and 'Depth segmentation (ex-travel)'.

## Run it

```
cd build
az login                                   (a user who can read the two Chill lakehouses)
run_all.bat 2026-07-14                     (cmd)
.\run_all.ps1 -T0 2026-07-14               (PowerShell)
python run_all.py --t0 2026-07-14          (any platform)
```

Several dates in one go: `run_all.bat 2025-06-30 2025-07-31 2025-08-31`. The offer levels take an anchor, the last day of
the renewal window: `set SC_ANCHOR=2026-06-30` before `run_all.bat`, `-Anchor 2026-06-30` in PowerShell, `--anchor` on
`run_all.py`, with or without dates. Each date pulls about a minute of data and builds
in under a minute. Outputs land in `../outputs`. The pull is skipped for files already in `build/_cache`; pass a new
`--cache` folder (or `--force`) to pull fresh.

Options on `run_all.py` (the bat and ps1 wrappers pass the date list; set the others as environment variables `SC_BASIS`,
`SC_KEYCARE`, `SC_TENURE_MID`, `SC_NO_PULL`):

| Option | Default | Meaning |
|---|---|---|
| `--basis wide` | wide | a policy is held at the date if its cover spans the date, whatever its status is today. The basis of every as-at reading since 5 Aug 2026 (the depth work, the Roll Forward pack). |
| `--basis fabric` | | only policies whose status today is New Business or Renewal, as the Fabric notebook read them. Reproduces the 14 Jul 2026 `seg` snapshot; wrong for any historical date. |
| `--keycare dated` | dated | a customer is Protected only if a KeyCare term is dated to the date (sold on or before it, inside the year before). The Aug 2026 rule. |
| `--keycare ever` | | the policy has ever carried a KeyCare sale. The July 2026 Fabric reading, which the depth work found leaks the renewal outcome. |
| `--tenure-mid 4` | 4 | years at which Establishing becomes Established. 4 is the agreed reading (the TENURE-4 structural workbook). 3 reproduces the earlier workbook; output names then carry `_tenure-3`. |
| `--no-pull` | | build from the cache without touching the lakehouse |
| `--strict` | | a WARN in validation fails the run |
| `--workbook` | | the TENURE-4 workbook's tables and tie-out, live (adds the anchor and the twelve month-ends it needs) |
| `--replay` | | the same tables from the workbook build's own inputs, no lakehouse |
| `--state-window workbook` | workbook | which renewals the workbook stage keeps: `workbook` as the workbook read them, `pack` the pack's wider reading |

## What the validation checks, and what it found

`sc_offers.py` is the offer-levels builder; `sc_build.py` the customer and policy tables. `sc_validate.py` runs after every build and prints PASS / WARN / FAIL per check.

1. Internal: one segment per customer; the holdings rule re-derived from the table's own columns agrees on every row;
   policy income and policy counts foot to the customer table.
2. Holdings against Fabric (`--t0 2026-07-14` only): the eight segment counts against `seg.value_segment_summary`.
3. Pricing against Fabric (same date): policies per product x segment x band against `seg.structural_policy`.
4. Depth against the published depth work (`--t0 2025-06-30` only): the tier of every July 2025 renewal against the label
   the 19 Aug 2026 depth build gave it, on both the published and the ex-travel rule.
4b. Offer levels against the workbook (`--anchor 2026-06-30` only): population against the workbook's renewal spine and the
   bands of every priced offer against the bands the workbook build saved.
5. Regression: against the summary this pack wrote the last time it ran for that date. A change is a WARN, not a FAIL: the
   lakehouse keeps moving, so a run on a later day usually shows some.

Results on 22 Sep 2026:

| Check | Result |
|---|---|
| Fabric reproduction, `--basis fabric --keycare ever`, 14 Jul 2026 | every holdings segment within 7% of Fabric, total within 3%; every pricing cell within 7.5% |
| Depth, 30 Jun 2025 | 99.66% of 30,262 July 2025 renewals get the published tier; ex-travel 99.65%; tenure sub-band 100% when run on the 3-year boundary the published labels used |
| Offer levels, year to 30 Jun 2026 | 260,112 renewals against the workbook's 260,136; offer bands agree with the workbook's saved bands on 99.98% (52-week) and 99.95% (four-week) of 256,725 priced offers; retention agrees on 99.99% of renewals (75.89% retained on both) |
| Default basis, 14 Jul 2026 | 262,410 customers against Fabric's 244,890 (+7%): the wide basis keeps policies whose cover spanned the date but whose status has since moved. WARN, by design. |

The 3% that remains on the Fabric basis is drift: the `seg` snapshot is an 11 Aug rebuild of 14 Jul data, and `ads.policy`
has moved since. It is not a rule difference.

## The TENURE-4 workbook's numbers

Kam asked for the code behind `Chill_Structural_Segmentation_2026-09-07_TENURE-4.xlsx`. Three scripts rebuild every number on its
seven data sheets from this pack's pulls and tie each one out against the workbook. The Glossary and Notes sheets are text and are
not rebuilt.

| Script | What it does |
|---|---|
| `sc_wb_pricing.py` | Renewal price grid, Pricing - offer levels, Pricing - offer bands |
| `sc_wb_depth.py` | Depth segmentation, Depth segmentation (ex-travel), Depth x price crosstab, Tenure profile |
| `sc_workbook.py` | runs both and ties every number out against `reference/workbook_TENURE-4_2026-09-07_cells.csv` (the workbook's cells, formula values worked out from their inputs) |

Two ways to run it, from `build`:

```
run_all.bat replay               (cmd)          no lakehouse: the tables from the inputs the workbook build itself read
.\run_all.ps1 -Replay            (PowerShell)
python run_all.py --replay       (any platform)

run_all.bat workbook             (cmd)          live: pulls and builds the renewal offers for the year to 30 Jun 2026 and
.\run_all.ps1 -Workbook          (PowerShell)   the customer tables at the twelve month-ends 30 Jun 2025 to 31 May 2026,
python run_all.py --workbook     (any platform) then the tables. Needs az login
```

The csv files are UTF-8 with a byte-order mark, so Excel reads the euro sign and the inequality signs in their headers.

The replay reads `reference/workbook_inputs_2026-08/`, the row-level inputs exported from the August 2026 build (each folder has
a README listing its files and columns). It runs the same table code, the depth cascade included, and every number comes back
exact: that shows the arithmetic is the workbook's. The live run shows how far the lakehouse has moved since August.

Outputs go to `outputs/workbook/` (`outputs/workbook/replay/` for the replay): one csv per table, laid out as on the sheet
(`<sheet>__<table>.csv`), `tieout_<anchor>.csv` with every number's workbook value, pack value and status, and
`tieout_summary_<anchor>.txt`. A number is exact, within tolerance (rates and shares within 0.3 points, counts within 0.5% or 2,
amounts, averages and years within 0.5%), outside, or not built. The deep-dive tables rank holding combinations by size, so
their rows are compared by name: a change in the order does not shift every row below it.

Results on 5 Oct 2026, both from a clean unzip, the live run with every pull fresh that day (about 20 minutes in all):

| Sheet | Numbers | Replay: exact | Live: exact | Live: within | Live: outside | Live: not built |
|---|---|---|---|---|---|---|
| Renewal price grid | 264 | 264 | 105 | 143 | 16 | 0 |
| Pricing - offer levels | 1,376 | 1,376 | 776 | 552 | 48 | 0 |
| Pricing - offer bands | 1,086 | 1,086 | 666 | 396 | 24 | 0 |
| Depth segmentation | 747 | 747 | 54 | 355 | 330 | 8 |
| Depth segmentation (ex-travel) | 840 | 840 | 55 | 401 | 383 | 1 |
| Depth x price crosstab | 960 | 960 | 83 | 424 | 452 | 1 |
| Tenure profile | 216 | 216 | 2 | 153 | 61 | 0 |
| All | 5,489 | 5,489 | 1,741 | 2,424 | 1,314 | 10 |

The replay also gives the 40 labels and notes the data decide (the holding combinations and their counts) as on the sheet.
Not built means a number on the sheet that today's data do not give: a holding combination that no longer ranks in its table,
or a rate the sheet prints only above a minimum count.

Why the live run moves, all of it data, not rules:
- **Totals hold.** The price grid pool is 256,699 renewals against the workbook's 256,701, retention 76.54% against 76.55%. The
  depth sheet's book is 354,248 renewals against 354,358, retention 64.08% against 64.06%. The tenure profile reads 297,985
  policies against 298,559, retention 71.04% against 71.12%.
- **Renewals the workbook could not yet resolve have since resolved.** The workbook counted 14,177 renewals as unresolved (no
  renewal and no lapse recorded, counted as lost). Today 13,393 are, as Chill has processed the outcomes since. Half the pricing
  cells outside tolerance are the unresolved counts, and overall retention moves by 0.03 points.
- **About 3% of renewals land in a different depth tier than in August.** Policies parked in the 'Insurer Invited' status drop out
  of the month-end customer tables (the status set reads each policy's status today, and the parked set moves on each month),
  Chill has reprocessed some policy histories, and 4.8% of policy codes now sit under a different SCV customer key. On the four
  depth and tenure sheets the median count moves by 1.2% (85% of counts within 5%) and the median rate by 0.17 points (87% within
  a point), so most of their cells fall just outside a 0.5% tolerance rather than far from it.
- **The price grid's year-one block** moves with the same customer data: given the workbook's own tenure values it ties exactly.
- **Cancellation dates after 2100** (1,925 corrupt records) are ignored here and were not in the workbook: a small effect on
  tenure.
- **Renewals.** The workbook read each policy's latest status only where its latest renewal date fell between 1 May 2025 and
  1 Aug 2027. `--state-window workbook`, the default, keeps that, so the renewal counts come back as the workbook's (260,136
  Motor, Home and Van renewals). `--state-window pack` takes the pack's wider reading, which counts 24 renewals that died mid-term
  as gone and leaves 114 more unresolved.

To run again on a later day, pass `--force` or a new `--cache`: the month-end customer tables and the policy-to-customer key map
must be pulled on the same day, or customer keys reassigned in between show as tier changes.

## The rules, in one place

Holdings segments (customer, July 2026, `fabric/Chill_Structural_Segmentation_Rules.md` section 3), assigned top down:
Trip Buyer (no core product) · Portfolio (3+ policies) · Multi-Product (2+ core products) · Multi-Policy (2 policies) ·
Protected Single (KeyCare) · Settled / Building / New Single by tenure. Every policy in force counts, travel included.

Depth tier (customer, 19 Aug 2026, the Glossary of the structural workbook): the same cascade with three changes. A
single-trip travel policy never counts toward holdings for a customer with a core product. One core product plus an
annual multi-trip travel policy is Multi-Product. Travel-only customers split into 8a (annual multi-trip in force), 8c
(two or more single trips in the last year) and 8b. Each core tier carries a tenure sub-band a / b / c.

Offer levels (renewal): every Motor, Home or Van renewal due in the window on the renewals fact spine, one row per policy
code and renewal month, terms cancelled more than 14 days before the due excluded, rows with no risk segment excluded. The
offer is banded against the tertiles of genuine offers to renewals due in the same product x risk segment in the trailing
window before the Monday of the renewal's week: 28 days (the operational read, falling back to the 52-week band where the
pool holds fewer than 200 offers) and 364 days (floor 100). Ties go to the lower band. The reference pool is the two years
of offers to the anchor. The same cut on the expiring premium gives the paid bands. Travel has no offers.

Retention on the offer levels is the workbook's four-signal read, applied in order: the fact's own flag; the same record
rolled on (renewal date more than 300 days past the due); a same-client replacement in the same product within 45 days
of the due under a different code; a fact row for the same code a year on. `retention_signal` says which fired.
`unresolved` marks a renewal with no retention signal and no lapse status, which the workbook counts as lost.

Pricing band (policy): the premium against the 33rd and 67th percentiles of its product x risk segment, boundaries frozen
on the calibration year Jul 2025 to Jun 2026 (`reference/pricing_cutpoints.csv`). Motor segments are Chill's
RiskProfileBand, Home is Basic or Enhanced by cover flags, Travel is annual or single trip by duration, Van is age-banded
from `reference/van_age_ref.csv`. Travel Single Trip is read in force here; the workbook reads it on a 12-month rolling
purchase basis, so that one cell differs from the workbook by design.

Tenure is the current continuous spell: cover intervals merged, a gap of more than 30 days starts a new spell. Bands: New under 1 year, Establishing 1 to 4, Established 4 and over. Income is
commission plus fees, never premium.

## Where the data comes from

`python sc_pull.py --sql-only` prints the queries. Two lakehouses, same login:

- DataScience Exploration `ChillLH`: `ads.policy`, `ads.finaleadmlink` (policy code to SCV key), `ads.policymotorproposer`
  (risk band), `ads.policyhome` (cover flags), `ads.policytravel` (void flag), and `seg.pricing_cutpoints`,
  `seg.van_age_ref` when reachable (copies in `reference/` otherwise).
- Dev_CGP `ChillLH`: `edw_sql09_20260805.tbl_fact_policy_sales` for KeyCare sales and
  `edw_sql09_20260805.tbl_fact_policy_renewals` for the offer levels. Those are dated copies; change `SALES_FACT` and
  `RENEWALS_FACT` at the top of `sc_pull.py` when Chill re-snapshot them.

A cancellation date after the year 2100 is corrupt (1,925 dead records) and is ignored: the renewal date ends the cover.
`policytravel.PolicyCode` is numeric and is cast before joining. `finaleadmlink` is reduced to one SCV key per policy code.

## The Fabric originals

`fabric/` holds the three PySpark notebook scripts that built the `seg` tables in July 2026 and the three one-off repairs
that preceded the August re-run, with the rules document. They run only as cells in the Fabric notebook of the
DataScience Exploration workspace; they are here as the reference implementation, not to run.

## Requirements

Python 3.10+, pandas, numpy, pyodbc, Microsoft ODBC Driver 18 for SQL Server, Azure CLI. Written and tested on Mac (22 Sep and
5 Oct 2026), not yet on a Windows machine. The bat and ps1 wrappers call the same Python runner, which sets every stage to UTF-8
(Windows defaults to cp1252), and the workbook stage was run under a non-UTF-8 locale, as Windows runs it, without fault. All text
files are UTF-8. Nothing in the pack holds a credential: the token comes from `az login` at run time.
