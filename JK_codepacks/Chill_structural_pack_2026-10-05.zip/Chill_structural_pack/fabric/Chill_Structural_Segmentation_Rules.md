# Structural Customer Segmentation — Rules Summary

**Rapier → Chill · draft for review**
**Snapshot:** 14 July 2026 · **Population:** 266,845 in-force policies · 242,236 customers · €27.25m Chill revenue

---

## 1. What this is

Two structural segmentations, built side by side and read together — never fused, because they answer different questions at different levels:

| | Grain | Question it answers |
|---|---|---|
| **Pricing** | Policy | Is this policy priced high, in line, or low **versus same-risk peers**? |
| **Value** | Customer | How embedded is this customer, and what are they worth to Chill? |

Price is a property of a *policy*; value is a property of a *customer*. Keeping them separate is deliberate — "this policy is high-value" isn't a sentence anyone can act on.

A note that runs through everything below: **value means what Chill earns — commission + fees — not premium.** Gross premium includes the ~5% government levy that passes straight through, and commission rates vary roughly 9–21% by product and insurer, so two policies of the same premium are not worth the same to Chill.

---

## 2. Pricing segmentation (policy level)

For every policy: read its risk/cover segment, then band its premium **within that segment** into Low / Mid / High. The point of banding within-segment is like-for-like — "priced in the most expensive third of drivers like you" — which the raw price alone cannot tell you. "High" is a **retention-risk** signal, not a value signal.

**Segment definitions, per product:**

| Product | Segment | Source |
|---|---|---|
| **Motor** | Chill's existing 5-band risk scheme: Young 17–24, Young 25–29, Mature Low NCD, Mature Med NCD, Mature High NCD | `RiskProfileBand` (age × NCD), already computed by Chill |
| **Home** | **Basic** (no accidental damage, no specified items) vs **Enhanced** (any accidental-damage cover, or specified items) | Cover flags on the home policy |
| **Travel** | **Annual Multi-Trip** vs **Single Trip** | Cover duration (≥ 360 days = AMT) |
| **Van** | **Age-banded** — Young 17-24 / Young 25-29 / Mature, premium tertiled within each. Uses driver age (`ClientAgeBand`). NCD isn't available at policy level (van quotes carry NCD but only ~7% link to the book), so the Mature band isn't NCD-split the way Motor's is | age, no NCD |
| **Life** | Out of scope (very low volume) | — |

**Banding method:** the premium at the 33rd and 67th percentiles of each segment's **calibration year** become the Low/Mid and Mid/High boundaries. Boundaries are **calibrated once (on the trailing year, Jul 2025 – Jun 2026) and then frozen** — a customer never changes band because the boundary moved, only because their price moved. Because they are frozen, the *book* does not split into equal thirds: it splits into whatever share sits below each fixed value, and that share moving between snapshots is the drift signal. Boundaries are re-cut only as a deliberate, governed decision. The full derivation is worked end to end for one segment on the last four tabs of `Chill_Structural_Segmentation_2026-08-05.xlsx` ("How bands are derived" onwards).

**Reading basis (revised 5 Aug 2026):** every segment is read **in force at the snapshot**, with one exception. **Travel / Single Trip is read as a 12-month rolling count of purchases.** A single-trip policy covers one holiday, so an in-force count samples each policy in proportion to trip *length*, and long trips cost more — the 14 Jul workbook read 793 policies at 77.8% High on that basis. On a 12-month reading it is 50,422 policies at 33.0 / 33.5 / 33.5. The boundaries did not change: Single Trip shares the same frozen cut-point version, reference window and calibration timestamp as the other eleven segments. Only the population being counted was wrong. Single-trip travel is a purchase, not a holding, and should be read as one.

> **Caveat — the even split is not yet a finding.** The reading window (12 months to 14 Jul 2026) overlaps the calibration year (to 30 Jun 2026) by **98.9%**: 49,844 of the 50,422 policies read are the same ones the boundaries were cut on. So ~33/33/33 is close to definitional at this snapshot — it shows the length bias is gone, not that the boundaries are validated. This differs from the annual products, where the in-force book and the calibration year are genuinely different populations (Motor Mature High NCD: 101,319 vs 55,811, splitting 37.0/32.9/30.1) and the gap from a third *is* signal. Single-trip is a pure flow that replaces itself annually, so it will drift off an even split faster than anything else in the book — **that drift, at the next snapshot, is the first real reading, and it makes single-trip the segment that governs the re-base cadence question.** Early pointer: the 578 policies inside the reading window but outside the calibration year (1–14 Jul 2026) split 22.5/29.8/47.8, though that is a fortnight of peak season on a thin sample.

**Lapse rate (added 5 Aug 2026):** a 12-month policy lapse rate is now reported per Low / Mid / High band. At-risk population = every policy in force one year before the snapshot; retained if the same policy is still in force a year later or the customer started a same-product policy within ±45 days of its cover end; lapsed otherwise. **The expensive third lapses hardest in 10 of the 12 risk segments**, with the ordering Low < Mid < High unbroken (Motor Young 17-24: 43.8% → 50.4% → 58.7%; Home Basic: 13.4% → 16.9% → 22.1%; Van Mature: 15.9% → 21.8% → 28.6%). The two exceptions are the two small van bands, too thin to read. Single-trip travel is excluded — it expires by design, so its rate is ~100% by construction.

---

## 3. Value segmentation (customer level)

Built from five structural facts about the customer's holding, combined into **8 named segments**. Method is a rules-based cross-tab, not clustering — the inputs are categorical, so the groups are transparent and stable rather than a re-fitting black box. (Clustering is reserved for the later *behavioural* work.)

**The five value axes:**

| Axis | Bands |
|---|---|
| **Tenure** — current continuous spell with Chill | New (< 1yr) · Establishing (1–3yr) · Established (3yr+) |
| **Policy count** | 1 · 2 · 3+ |
| **Product breadth** (excl. Travel) | Single · Multi · Travel-only |
| **Add-on** | Holds KeyCare · None |
| **Payment** | Annual · Financed · Mixed |

**The 8 segments** (hierarchical and mutually exclusive — every customer in exactly one, assigned to the richest rule they match):

| Segment | Definition | Customers | % | € / customer |
|---|---|---:|---:|---:|
| Portfolio | 3+ policies | 2,077 | 0.9% | €342 |
| Multi-Product | 2+ core products | 12,751 | 5.3% | €221 |
| Multi-Policy | 1 product, 2 policies | 6,548 | 2.7% | €186 |
| Protected Single | 1 policy + KeyCare | 22,386 | 9.2% | €158 |
| Settled Single | 1 policy, 3yr+, no add-on | 78,065 | 32.2% | €117 |
| Building Single | 1 policy, 1–3yr | 46,059 | 19.0% | €115 |
| New Single | 1 policy, < 1yr | 38,297 | 15.8% | €101 |
| Trip Buyer | Travel only | 36,053 | 14.9% | €19 |

The underlying cross-tab (88 occupied combinations) is retained beneath the names, so any segment can be decomposed back to its exact make-up.

---

## 4. Three findings worth flagging

1. **The lever is depth, not time.** Tenure looks like a strong value driver book-wide (New €87 → Established €131), but hold depth constant and it nearly vanishes (€101 → €117). Established customers are worth more mainly because they've *accumulated* products and add-ons — not because time itself pays. The commercial move is cross-sell: a Settled Single is worth €117; add one product and they're worth €221.
2. **Tenure is not a one-way ratchet.** 28% of live customers have lapsed and returned at least once, resetting their tenure clock. Any forward projection must allow customers to move backwards, not only forwards.
3. **The multi-product base is small.** Only 5.3% of customers hold 2+ core products; Trip Buyers are 15% of customers but 2.5% of revenue; KeyCare punches above its weight at 9% of customers / 13% of revenue.

---

## 5. What Chill needs to confirm

These are the points where the rules depend on a Chill definition or decision:

| Item | Status |
|---|---|
| **Tenure definition** | We use *current continuous spell* (resets on lapse-and-return). Needs confirming: what gap length breaks a spell, and that "Renewal Transfer" / "Lapsed for Transfer" are administrative and do **not** reset it. |
| **Payment type** | Currently a stand-in (financed flag). Needs the real direct-debit-vs-annual definitions. |
| **Van pricing** | Age-banded (Young / Mature) but not NCD-split — NCD isn't available at policy level (quote NCD reaches only ~7% of the book). Full risk-banding needs NCD carried onto the van policy record. |
| **Life** | Confirm it stays out of scope. |
| **Segment names** | The 8 names are candidates — for sign-off against the operational test (can a Commercial / CRM / Contact-Centre manager read it and know what to do?). |
| **Travel in product breadth** | We exclude it (a €19 travel policy vs €160 van). Flag: this differs from a raw multi-product count if Chill already reports one. |
| **Commission / fee columns** | Confirm `CCYFees` is Chill income (not pass-through) and that premium is levy-inclusive. |
| **Re-base cadence** | Frozen pricing boundaries will need a governed re-cut cadence as premiums inflate. |

---

## 6. Ownership

Consistent with the Functional Spec: **Chill owns** the pricing/risk classifications, the product rules (incl. Van), and sign-off on segment names, thresholds and the tenure definition. **Rapier owns** the segmentation derivation, the multi-product roll-up, and keeping the reads reproducible and stable across snapshots.
