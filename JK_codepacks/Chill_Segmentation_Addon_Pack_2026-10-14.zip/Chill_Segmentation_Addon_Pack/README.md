# Chill segmentation add-on pack

This pack builds the four table sets that sit on top of the production pack, for any month-end the production pack has been run for:

1. **SCV readings:** every customer and every policy at the snapshot with all six segmentation options and the items inside each component, and the twelve months after the snapshot once they can be read.
2. **Risk features:** the relationship-risk model's full input set, the reasons behind each score, digital, web, email and Motor quote engagement, the last renewal cycle in detail, triggers and a priority tier, for every customer and every policy.
3. **Acquisition and cross-sell:** how each customer acquired in the year came to Chill, what they bought next, every new-business sale, and every Home online quote.
4. **Behaviour rates:** the behaviour counts read against the opportunity for them, so a customer who does a lot is not read as one who struggles, engages or shops a lot.

It pulls from Fabric, read-only, and writes parquet tables and data dictionaries for loading into Fabric. With `--xlsx` it also writes each table as an Excel workbook. Built on 14 Oct 2026 for Vijay.

## The tables

Written to `outputs/<snapshot>/`:

| File | Grain | Suggested Fabric table |
|---|---|---|
| `Chill_SCV_Readings_<snapshot>.parquet` | snapshot, scv | `seg.scv_readings` |
| `Chill_Policy_Readings_<snapshot>.parquet` | snapshot, code | `seg.scv_policy_readings` |
| `Data_dictionary_SCV_Readings_<snapshot>.csv` | snapshot, file, column | `seg.scv_readings_dictionary` |
| `Chill_Risk_Features_SCV_<snapshot>.parquet` | snapshot, scv | `seg.risk_features_scv` |
| `Chill_Risk_Features_Policy_<snapshot>.parquet` | snapshot, code | `seg.risk_features_policy` |
| `Data_dictionary_Risk_Features_<snapshot>.csv` | snapshot, table, column | `seg.risk_features_dictionary` |
| `Chill_Acquisition_CrossSell_SCV_<snapshot>.parquet` | snapshot, scv | `seg.acquisition_crosssell_scv` |
| `Chill_New_Sales_<from>_to_<end>.parquet` | policy_code | `seg.new_sales` |
| `Chill_Home_Quotes_<from>_to_<end>.parquet` | one Home online quote | `seg.home_quotes` |
| `Data_dictionary_Acquisition_CrossSell_<snapshot>.csv` | snapshot, table, column | `seg.acquisition_crosssell_dictionary` |
| `Chill_Behaviour_Rates_SCV_<snapshot>.parquet` | snapshot, scv | `seg.behaviour_rates_scv` |
| `Chill_Behaviour_Rates_Policy_<snapshot>.parquet` | snapshot, code | `seg.behaviour_rates_policy` |
| `Data_dictionary_Behaviour_Rates_<snapshot>.csv` | snapshot, table, column | `seg.behaviour_rates_dictionary` |

These are the names the tables already have in the DataScience Exploration lakehouse for 30 Jun 2024, 2025 and 2026.

- **Keys:** customer tables join on `scv` and `snapshot`, policy tables on `code` and `snapshot`, to each other and to the production pack's `customer_segments` and `policy_readings`.
- **Whole-history tables:** new sales and Home quotes cover the whole sales history up to the end of the sales records, not the snapshot. The same table is written for every snapshot run on the same pulls. Load one copy and replace it when the pulls are refreshed.
- **Dictionaries:** one CSV per set, with a row per table and column. They define every column: its meaning, window, source and caveats.

## Before the first run

1. **The production pack.** This pack reads the production pack's run for the same month-end: its stage outputs, its pulls and its behaviour stage's shared build. Keep the production pack in a folder called `Chill_Segmentation_Pack` beside this one, or give its folder with `--pack`. If the production pack ran with `SEG_CACHE` set, set the same `SEG_CACHE` here.
2. **Software.** The same as the production pack: Python 3.11 or later, Microsoft ODBC Driver 18 for SQL Server, and the Azure CLI signed in once with `az login`. Then, from the `build` folder: `pip install -r requirements.txt`. The versions match the production pack's, which the frozen risk model needs.
3. **Long paths on Windows.** The production pack's cache paths are long. Either keep both packs near the drive root, for example `C:\chill\Chill_Segmentation_Pack` and `C:\chill\Chill_Segmentation_Addon_Pack`, or switch on long paths once as an administrator: `reg add HKLM\SYSTEM\CurrentControlSet\Control\FileSystem /v LongPathsEnabled /t REG_DWORD /d 1 /f`. The runner warns when they are off and the folder path is long.

## Running it

First the production pack for the month-end, then this pack, from `build` in Windows cmd:

```
run_all.bat --snapshot 2026-08-31              pull what is missing, then build the four sets
run_all.bat --snapshot 2026-08-31 --no-pull    rebuild from the pulls already in the cache
run_all.bat --snapshot 2026-08-31 --from a40   rerun from step a40 onwards
run_all.bat --snapshot 2026-08-31 --xlsx       also write the xlsx workbooks
run_all.bat --sql-only                         print every query (source_queries.sql is this output)
```

PowerShell users can run `run_all.ps1` with the same arguments, and Mac or Linux users `run_all.sh`. Add `--pack <folder>` when the production pack is elsewhere, and `--force-pull` to refresh the pulls.

- **Order of runs:** the runner stops with what to do when the production pack has no run for the snapshot.
- **Process:** each pull and step runs as its own process, one after another. Only one Fabric connection is ever open.
- **Folders:** pulls land in `_cache/raw`, the keyed Motor quotes in `_cache/derived`, step working files in `_cache/stage/<snapshot>`, and the tables in `outputs/<snapshot>`. Set `ADDON_CACHE` or `ADDON_OUT` to move them.
- **Which pulls repeat:** every pull here is whole-history, kept and reused by later snapshots. Add `--force-pull` to refresh them, for example once a month before the month's run.

**Time and memory,** measured on a 24 GB laptop:
- **Pulls:** about 30 minutes from an empty cache, most of it the Motor quote engine (7 minutes), the campaign history (10 minutes in all) and the renewals and sales facts. Every pull is reused by later snapshots, so a later month-end needs none unless they are refreshed.
- **Steps:** about 5 minutes a snapshot. The behaviour rates take about 3 of them and the risk features about 1.5.
- **Workbooks (`--xlsx`):** about 7 minutes more, writing about 750 MB of xlsx a snapshot. The largest, the risk features customer workbook, is about 200 MB.
- **Memory:** 16 GB is enough. The steps peak at about 7 GB resident, the workbooks at about 5 GB. The production pack needs more (32 GB advised), so a machine that runs it runs this.
- **Disk:** about 2 GB for the pulls and keyed quotes, about 150 MB of working files and 220 MB of tables a snapshot, and 750 MB more with the workbooks.

## The twelve months after the snapshot

The outcome columns, such as loss, renewals due and renewed, income a year on and the year-on cross-sell, read the twelve months after the snapshot. They are filled only when the production pack also has a run for the month-end a year later, because that run's holdings, income and renewal register cover the year. The runner says at the start whether they will be filled.

So at a current month-end they are left out. To fill them for, say, 31 Aug 2025: run both packs for 31 Aug 2026, then rerun this pack for 31 Aug 2025 with `--no-pull --from a20`.

## What each step does

| Step | What it builds | Reads |
|---|---|---|
| a10_quote_keys | Motor quotes keyed to customers: through the sold policy, the quote's email where it belongs to one customer, then the episode table's key | The quote pulls and the policy register link |
| a20_readings | The SCV readings: every customer and policy at the snapshot, from the production pack's tables, with rolling management, in-life quotes, comms read per message, price by product, and outcomes once they can be read | The production pack's run for the snapshot (and a year later), the comms pulls |
| a30_shap | Each policy's relationship-risk score and its attributions (SHAP) from the production model, checked against the production pack's scores | The production pack's risk inputs and frozen model |
| a40_risk_features | The risk features customer and policy tables | Steps a10 to a30, the risk pulls, the production pack's behaviour build |
| a50_acquisition | New sales, Home quotes, and the acquisition and cross-sell customer table | The acquisition and quote pulls, step a40 |
| a60_behaviour_rates | The behaviour rates customer and policy tables | Steps a40 and a50, the production pack's behaviour build and call log |
| x90_workbooks | Only with `--xlsx`: every table as an xlsx workbook, with Start here, Data, Data dictionary and Glossary sheets | The tables above |

## Loading the tables into Fabric

As for the production pack. Upload the files to the lakehouse's Files area, then in a notebook:

```python
spark.read.parquet("Files/segmentation/Chill_Risk_Features_SCV_2026-08-31.parquet") \
     .write.mode("append").saveAsTable("seg.risk_features_scv")
spark.read.option("header", True).option("multiLine", True).option("escape", '"') \
     .csv("Files/segmentation/Data_dictionary_Risk_Features_2026-08-31.csv") \
     .write.mode("append").saveAsTable("seg.risk_features_dictionary")
```

Rerunning a snapshot means deleting that snapshot's rows first. New sales and Home quotes are replaced whole (`mode("overwrite")`).

## Things to know

- **Risk is scored by the production model at every snapshot,** the frozen model in the production pack's `build/models`, so the add-on's scores equal the production pack's. Inside the model's training period, Dec 2024 to Jun 2025, the scores are in-sample, and before it a backcast: the dictionaries say which. The 30 Jun 2025 files delivered in October carried cross-fitted scores (each customer scored by a model that never saw them), so a rerun at 30 Jun 2025 differs from them in risk and the columns built on it: risk correlates at 0.98, the first reason agrees for 87% of customers and the priority tier for 97%.
- **The facts are the 5 Aug 2026 dated copies.** The renewals and sales facts come from the production pack's settings (`SEG_RENEWALS_FACT`, `SEG_SALES_FACT`), and the Motor quote engine fact from `ADDON_MFQ_FACT`, the same dated copy by default. On these, a snapshot after 5 Aug 2026 reads no cross-sell and finds no acquisition sale for a spell begun after that day, and the acquisition step warns. Point the three settings at the live tables once Chill refreshes them, then rerun the pulls with `--force-pull`.
- **Latest-state columns.** `payment_band` (SCV readings and risk features) and `policy_finance_flag` (risk features policies) read a finance flag that keeps only its current value. They are filled only when the production pack pulled its structural tables within about six months after the snapshot, and left blank on older snapshots, where they would show later changes.
- **Cross-sell** in the acquisition table reads the sales records, not the production pack's run a year on, so it is filled at every snapshot over the days the sales records cover after it, up to twelve months: `xsell_window_days` says how many.
- **Comms** are read per message: messages sent in the twelve whole months before the snapshot's month, and of those the ones opened or clicked by the snapshot. The add-on pulls the campaign history at message grain itself. Its sends are checked against the production pack's monthly campaign pull, and since the two pulls are made at different times the check only warns.
- **An earlier reading start.** For a snapshot before mid-2025 the production pack runs with `SEG_BEH_START`, as its README says. The add-on picks that start up from the production pack's run, with nothing to set here.
- **Checks that warn rather than stop.** Where a source can drift between pulls (the GA4 sessions against the production pack's, the comms sends against its monthly pull, a renewal window with action but no action day, Home quote dates the system cannot have), the step prints a warning, counts it in its `diag.json` under `_cache/stage/<snapshot>/<step>`, and carries on. Checks between two readings of the same source still stop the run.
- **Not in this pack:** the retention priority workbook of 29 Sep 2026 (the trigger test, the tier back-test and the model test), a one-off analysis across three snapshots. The trigger columns and the priority tier it describes are in the risk features tables. Writing to Fabric is also left to the notebook above: like the production pack, this pack only reads.

## Verification

Built on 14 Oct 2026 and checked seven ways against the files delivered in early October (the SCV readings, risk features, acquisition and cross-sell, and behaviour rates folders for 30 Jun 2024, 2025 and 2026).

1. **The pulls:** every query is the one the delivered files were pulled with, character for character, at the default settings. Pulled fresh on 14 Oct, the 22 files hold the same rows as the September and October pulls, except that Chill's identity resolution has since moved the customer key of 53,963 policy records (2.5%).
2. **Step by step, from the inputs the delivered files read:** before the tie rules in point 5, every table reproduced the delivered one exactly at all three dates: same rows in the same order, same columns, same values. At 30 Jun 2025 that holds once the delivered build's cross-fitted risk scores are put in place of the production model's, as described under Things to know.
3. **End to end, from the production pack's outputs alone:** at 30 Jun 2024 and 2026 every table is identical to the delivered one, apart from the tie rules in point 5. At 30 Jun 2025 the same holds for the acquisition and behaviour rates tables, and the SCV readings and risk features differ besides in risk and the columns built on it.
4. **Row order:** Fabric returns query rows in no fixed order, so every input was shuffled (the add-on's pulls and the production pack's files it reads) and the run repeated, three times over two snapshots. Every table and dictionary came back with the same values.
5. **Tie rules:** the shuffles found a few readings whose result depended on row order when two candidates tied: the device most quotes started on, the last renewal window when two close on the same day, the risk segment and cover type of two policies with equal income, the priority rank on equal income at risk, and a quote recorded twice under one id. Each now has a stated rule (in the dictionary), so the same data always gives the same answer. Against the delivered files, those columns move for at most 0.2% of customers: for example primary_device for 502 of 265,965 at 30 Jun 2026, and the last_renewal_ columns for up to 402.
6. **Workbooks:** every text sheet passes the fit check, every workbook renders to PDF, and every Data sheet matches its parquet table cell for cell at the sheet's rounding.
7. **Windows:** every file is read and written as UTF-8, the code uses no shell, links or machine paths, every module imports cleanly, the code parses as Python 3.11, and run_all.bat has Windows line endings.
