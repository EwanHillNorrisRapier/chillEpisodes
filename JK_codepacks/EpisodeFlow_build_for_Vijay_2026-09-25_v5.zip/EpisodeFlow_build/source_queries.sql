-- ef_motor_eligible.csv
SELECT PolicyCode, RenewalDate, TyPolicyCode, TyPolicyRenewDateAdj, PolicyRetNum, tyreportingsaledate
FROM stg.r0_motorpolicieseligibleforrenewals
ORDER BY PolicyCode, RenewalDate

-- ef_motor_renewal_events.csv
SELECT SourcePolicyReference AS code, EventTypeId AS step, EventDateTime AS ts, Grain AS grain, SCV_Customer_Key AS scv,
       EventId AS eid, SourceQuoteReference AS quote, SourceCustomerReference AS custref, EventSourceReference AS esr
FROM ods.scvepisodeeventstreamfinal
WHERE PolicyTypeGroup = 'Motor' AND EventTypeId LIKE 'R%'

-- ef_code_scv_linkfinal.csv
SELECT DISTINCT l.ChillSourcePolicyReference AS code, l.SCV_Customer_Key AS scv
FROM ods.scveadmlinkfinal l
JOIN (SELECT DISTINCT PolicyCode FROM stg.r0_motorpolicieseligibleforrenewals) e ON e.PolicyCode = l.ChillSourcePolicyReference
WHERE l.ChillSourcePolicyReference IS NOT NULL

-- ef_renewals_money.csv
SELECT TRIM(PolicyCode) AS code, NULLIF(TRIM(COALESCE(NewPolicyCode,'')),'') AS new_code, RenewalMonth,
       LYPolicyRenewDateAdj AS due, LYPolicyTypeGroup AS product,
       LYEURGrossPremium AS expiring_gwp, LYEURCommission AS expiring_commission, LYEURFees AS expiring_fee,
       RenEURPremInviteOrig AS invite_original_premium, RenEURPremInvite AS invite_premium, RenEURPremOffer AS offer_premium,
       RenEURPremAlternative AS alternative_premium, RenEURFee AS offer_fee,
       TYEURGrossPremium AS settled_gwp, TYEURCommission AS settled_commission, TYEURFees AS settled_fee,
       PromoCodeApplied AS promo_applied, PromoCodeAmount AS promo_amount, PromoCodeDate AS promo_date, PromoCodeTreatment AS promo_treatment,
       PolicyRetNum, PolicyRetType, MTAFlag
FROM edw_sql09_20260805.tbl_fact_policy_renewals
WHERE LYPolicyTypeGroup = 'Motor' AND RenewalMonth >= '2024-07-31' AND RenewalMonth <= '2026-07-31'

-- ef_stream_steps.csv
SELECT PolicyTypeGroup, EventTypeId, COUNT(*) AS n, MIN(EventDate) AS d0, MAX(EventDate) AS d1
FROM ods.scvepisodeeventstreamfinal
GROUP BY PolicyTypeGroup, EventTypeId

-- (ods.scveadmlinkfinal has been rebuilt with different column names; the live pull reads the column list and uses whichever of ['PolicyCode', 'SourcePolicyReference', 'ChillSourcePolicyReference'] / ['SCV_Customer_Key_Final', 'SCV_Customer_Key'] is there)

-- build config
SELECT startTime, endTime, effectiveDate FROM stg.episodeeventstream_buildconfig
