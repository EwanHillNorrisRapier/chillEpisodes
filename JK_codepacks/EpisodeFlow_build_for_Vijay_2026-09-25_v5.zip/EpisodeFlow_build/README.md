# Episode Flow extract, Motor renewal: how the outputs are built

This folder holds the code that produces
`Chill_EpisodeFlow_MotorRenewal_<date>.xlsx` and `Chill_EpisodeFlow_MotorRenewal_entries_<date>.csv`.
Four stages, run in order. Each writes into a cache folder and the next reads from it.

| Stage | Script | Reads | Writes |
|---|---|---|---|
| 0 pull | `ef_pull.py` | Dev_CGP lakehouse (SQL endpoint) + John's `Chill_Episode_Frameworks.xlsx` | `ef_motor_eligible.csv`, `ef_motor_renewal_events.csv`, `ef_code_scv_linkfinal.csv`, `ef_stream_steps_<date>.csv`, `framework_data_view.csv`, `ef_pull_manifest.json` |
| 1 prep | `ef_prep.py` | the five CSVs above | `ef_entries.parquet` (one row per entry), `ef_events_attached.parquet`, `ef_step_register.csv`, `ef_k1_july_steps.csv`, `ef_prep_diag.json` |
| 2 calc | `ef_calc.py` | the parquet files | `ef_results.pkl` (every table in the workbook), `ef_entries_export.csv` |
| 3 write | `ef_write.py` | `ef_results.pkl` | the xlsx and the entries csv in `outputs/` |

`run_all.py` runs the four in order on Windows, Mac or Linux. `run_all.ps1` (PowerShell), `run_all.bat` (cmd) and
`run_all.sh` (bash) are wrappers with the same options.

```bat
run_all.bat _cache_2026-09-22 2026-09-22 "C:\path\Chill_Episode_Frameworks.xlsx"
```

```powershell
cd EpisodeFlow_build\build
az login                                   # a user who can read the Dev_CGP lakehouse
python run_all.py --cache .\_cache_2026-09-22 --stamp 2026-09-22 --framework "C:\path\Chill_Episode_Frameworks.xlsx"
```

Options: `--anchor` (last day of the current window), `--stream` (which stream table), `--cache` (folder for the pulled and intermediate files), `--stamp` (date in the output file names), `--framework`
(John's workbook; only needed the first time into a new cache), `--out` (output folder, default `..\outputs`),
`--no-pull` (skip stage 0 and build from CSVs already in the cache). Environment variables `EF_CACHE`, `EF_STAMP`,
`EF_OUT` do the same job when the stages are run one at a time.

## The source queries

`python3 ef_pull.py --sql-only` prints them. They are plain T-SQL against the Dev_CGP lakehouse `ChillLH`
and can be run in a Fabric notebook instead. The four are:

1. Renewals due: every column of `stg.r0_motorpolicieseligibleforrenewals`. One row per PolicyCode x RenewalDate.
   `TyPolicyCode` populated means the policy renewed. This table is the entry grain: one entry per row.
2. Renewal steps: `ods.episodeeventstream` where `PolicyTypeGroup = 'Motor'` and `EventTypeId` starts with `R`,
   as `code, step, ts, grain` (SourcePolicyReference, EventTypeId, EventDateTime, Grain).
3. Customer key: `ods.scveadmlinkfinal` policy code -> SCV customer key, restricted to codes on the due list. The table has been
   rebuilt with different column names several times (SourcePolicyReference / SCV_Customer_Key on 19 Sep, PolicyCode /
   SCV_Customer_Key_Final on 21 Sep, ChillSourcePolicyReference / SCV_Customer_Key on 25 Sep); `ef_pull.py` reads the live
   column list and uses whichever pair is there, and stops with the column list if it finds none.
4. Inventory: rows, first and last EventDate per PolicyTypeGroup x EventTypeId, from the whole stream. Feeds sheet A2.

Plus `stg.episodeeventstream_buildconfig` for the stream's window, recorded in the manifest.

## Which stream table, and where the customer key comes from

`ef_pull.py` uses `ods.scvepisodeeventstream` when it exists (every column of `ods.episodeeventstream` plus
`SCV_Customer_Key`, built with Vijay's SCV joins) and falls back to `ods.episodeeventstream`. Force one with
`--stream schema.table` or the `EF_STREAM` environment variable. The first lines of the pull print which table was used
and whether it carries the key, and the manifest records both.

When the stream carries the key, each event comes down with it and `ef_prep.py` keys every policy code from the stream.
`ods.scveadmlinkfinal` is still pulled, as the fallback for a policy code with no keyed event. The entries CSV says which
was used per row in `scv_source` (stream / link table / not keyed). `Cust` on every page is the count of distinct SCV keys.
The windows are unchanged: renewals due 1 Jul 2025 to 30 Jun 2026, prior 1 Jul 2024 to 30 Jun 2025, July 2026 check month.
`ef_prep_diag.json` gains four lines: events with no customer key, codes keyed by the stream, codes keyed by the link
only, codes where stream and link disagree.

## Events with no policy code

Attachment works on policy code. On the SCV-keyed stream an event that has no policy code but does have a customer key
(today: the 39,883 failed inbound call rows, R3b.F1) is attached through the customer instead: it goes to that customer's
nearest Motor renewal, inside the same window of 150 days before to 215 days after the renewal date. Where the customer
has more than one renewal in reach, the nearest takes it and the row is flagged `ambiguous_cycle` in
`ef_events_attached.parquet`, which also says per event whether it was `attached_by` policy code or customer key.
`ef_prep_diag.json` reports how many such events there were, how many attached, how many were ambiguous and how many
found no renewal. `ef_step_register.csv` has the count per step in `attached_by_customer_key`. On the plain stream these
events attach to nothing, as before. The function is `attach_by_customer()` in `ef_prep.py`.

## Counts with no policy join: customers and units per step

Everything above attaches events to renewal entries, which needs a policy code or, failing that, a customer key.
The sheet `Steps by customer` and the file `Chill_EpisodeFlow_MotorRenewal_stepcounts_<date>.csv` count every row of
every step without any join: distinct SCV customer keys, distinct units, distinct events, for all time and for the
current window, prior window and check month by EVENT date. A step keyed only by quote reference or call id is counted
there in full.

The unit is what one row of the step stands for, read from the stream's `Grain` column, and its reference sits in a
different column per grain:

| Grain | unit kind | reference column |
|---|---|---|
| Policy | policy | SourcePolicyReference |
| Quote, Payment Attempt | quote | SourceQuoteReference |
| Call, GenesysCall | call | EventSourceReference (the call id), else EventId |
| Customer | contact | SourceCustomerReference (phone or email) |
| Email, User | contact | SourcePolicyReference, which holds an email on these grains |
| anything else | event | first reference present, else EventId |

The mapping is `UNIT_OF_GRAIN` at the top of `ef_prep.py`. A new grain in the stream falls to `event` until it is added
there. The pull now brings EventId, SourceQuoteReference, SourceCustomerReference and EventSourceReference down with
every event, and `ef_events_attached.parquet` carries `unit_kind` and `unit` per attached event. On a pull from the
plain stream the customer count is zero, because that table has no key.

## Moving the windows

One date drives everything: the anchor, the last day of the current window. Default 2026-06-30, as the requirement sets
it. Pass `--anchor YYYY-MM-DD` to `run_all.py` (fourth argument of `run_all.bat`, `-Anchor` in PowerShell, or set
`EF_ANCHOR`). Current window = the twelve months ending the anchor, prior window = the twelve months before that, check
month = the calendar month after the anchor, data end = the last day of the check month. The window labels on every
sheet and the value of the `window` column in the CSV follow. Sentences in the workbook narrative that spell out
"July 2026" do not. The register columns `attached_current`, `attached_prior`, `attached_check_month` and
`attached_outside_windows` show where a step's attached events fall, so a step that only fires in the check month no
longer looks as if it dropped out.

## Testing a change to the stream

Rebuild into a new cache folder with a new stamp and compare with the previous run. Nothing in an earlier cache
or output is touched. Two files tell you quickly whether the stream changed:

- `ef_prep_diag.json`: raw rows, undated rows, rows with no policy code, duplicates dropped, rows attached to a cycle.
- `ef_step_register.csv`: per step, raw rows, undated, deduplicated, attached, first and last firing month.

The workbook's `Steps` sheet is the register laid out, and the `Read me` items describe the stream as this run found it:
since 25 Sep 2026 their figures are computed from the data (invitation rows per code, synthetic timestamps, duplicate rows,
step aliases, R3.O1 firing on renewed policies, undated rows, steps outside the framework), so a stream fix moves them.

## Things to know before changing the code

- Entries are keyed off the renewals-due table, not the R1a invitation, because R1a fires once per policy code in the
  stream. Events attach to the cycle whose renewal date they sit nearest, inside 150 days before to 215 days after,
  and a cycle accepts events stamped with the predecessor or successor policy code. If the stream gains a cycle key,
  `ef_prep.py` `attach()` is where that would replace the date-window rule.
- Rows identical on (code, step, timestamp) are dropped as duplicates. Steps in `ALIASES` (`ef_prep.py`) are dropped
  as copies of another step.
- The last step is ranked by framework order, not time, because thirteen steps carry synthetic timestamps.
- `framework_data_view.csv` is John's Data View sheet read with the header on row 4. Step types (FRICTION, OUTCOME,
  HAPPY_PATH, CHILL_EFFORT) and the attaches_to column drive the difficulty and point reads.
- Windows and the data end are constants at the top of `ef_prep.py` (current Jul 2025 to Jun 2026, prior Jul 2024
  to Jun 2025, July 2026 check month, data end 31 Jul 2026).
- Reconciliation figures on sheet K (SL04 offered and renewed, D7 dues) are literals in `ef_write.py` from the
  Roll Forward pack v7 of 16 Sep 2026. They do not move when the stream does.

## Requirements

Python 3.10+, pandas, pyarrow, openpyxl, pyodbc, and Microsoft's ODBC Driver 18 for SQL Server. Azure CLI logged in
as a user who can read Dev_CGP. Tested on Mac; the 21 Sep bundle failed on Windows on a date format (`%-d`), fixed the same evening,
and text files are now written and read as UTF-8 on every platform. The SQL endpoint refuses parallel connections, so run one pull at a time. If a table
reads zero rows the endpoint's metadata is stale: refresh it (SQL analytics endpoint -> Refresh) and rerun.
The events pull is 7 to 8 million rows and is the slow step. The whole chain runs in well under an hour on a laptop.

The stream defects the 19 Sep 2026 extract found are listed on the Read me sheet of Chill_EpisodeFlow_MotorRenewal_2026-09-19.xlsx, items 1 to 13.

## Money per entry (requirement v0.5, section L)

The pull brings the Motor rows of Chill's renewals fact for both windows and the check month (`ef_renewals_money.csv`).
`ef_calc.py` keys each entry to its fact row on policy code and the month-end of its renewal date (then the month before
or after) and writes `Chill_EpisodeFlow_MotorRenewal_money_<date>.csv`, one row per entry: expiring premium, commission
and fee; the invite as first shown and the final offer; the settled premium, commission and fee on renewed entries only;
the computed differences; the promo code applied. The `L Money` sheet has the sums per window and the match coverage
(every current-window entry matched in the same month on the 22 Sep run). Column dictionary on the `CSV columns` sheet.

## Stream to entries: the reconciliation (requirement v0.5, M4)

`ef_prep.bridge()` labels every raw stream row dated inside the current window with what happened to it: undated, no
policy code, alias, duplicate, code not on the due list, no renewal cycle in reach, or attached and to which window's
entry. The `Stream to entries` sheet (and `..._bridge_<date>.csv`) shows it per step and foots on every step to the
Steps sheet's firings on current-window entries. Read it before calling a stream-to-CSV difference a mismatch: the stream
is dated by event and the entries by renewal date, so a June event sits on a July renewal. It also shows that most
re-quote events in the window carry a former customer's old policy code and so find no live renewal.

## The stream table

`ef_pull.py` takes the first of `ods.scvepisodeeventstreamfinal`, `ods.scvepisodeeventstream`, `ods.episodeeventstream`
that exists. The `final` table (21 Sep 2026) is the whole stream with the SCV customer key. `--stream` overrides.

## What is not recomputed on a rerun

The tables, the `Steps` register, `ef_prep_diag.json` and, since 25 Sep 2026, the figures in the `Read me`, `Requirement`,
`CSV columns` and `Definitions` sheets are computed from the data every time. Two things are not:

- The tie figures on sheet K (SL04 offered and renewed, D7 dues, B6 lapses) are literals from the Roll Forward pack v7 of
  16 Sep 2026 (`TIE` in `ef_write.py`). The K2 text checks the entries against them and says so if they stop tying.
- A few explanatory sentences describe how the stream behaves (for example that R3b and R4 are stamped with the new policy
  code). They are true of every pull so far; check them if the stream is rebuilt.

## Step ids renamed or split in the stream

- 22 Sep 2026: `RO.F1` / `RO.F2` became `R0.F1` / `R0.F2`. `RENAMED` in `ef_prep.py` maps the old ids to the new ones, so an
  older cache still builds.
- 24 Sep 2026: the framework's R2 'Customer logs in to portal' is split into `R2a` (logins, policy grain) and `R2b` (calls to the
  call centre, call grain, no policy code). Point R2 is reached by either (`POINTS` in `ef_prep.py`), R2b attaches through
  the customer key like the other calls, and `D Paths` splits every entry into login only / call only / login and call /
  neither. 'Neither' is derived: the stream has no no-show step. The entries CSV gains `path_R2__login`, `path_R2__call` and
  `r2_route` as its last three columns, so every earlier column keeps its position.
- 24 Sep 2026: `R3.B1.2.F1` 'Unreachable on the lapse sequence' no longer appears and `R3.B1.1.F1` 'CRM bounces' does. The
  new id is not in the framework; it is typed FRICTION by its id and listed with the other steps outside the framework.
- Customer keys of zero or below are placeholders, a different one on every row (an unidentified caller). Since 25 Sep 2026 they
  are treated as no key: such a call cannot be attached, is counted under 'no policy code' in the bridge, and is not a customer
  in the Cust counts. Two calls by one customer at the same minute count once.

## Test rerun, 21 Sep 2026

`run_all.sh` was run end to end from a live pull into `_cache_2026-09-21` (pull 8 minutes, whole chain 12 minutes).
Against the 19 Sep extract: R2 and R2.F1 now carry timestamps on every row (797,454 undated rows on 19 Sep, 0 now),
R1.B2 rose from 6,367 rows to 250,991 and R2.E1 from 5,705 to 227,669. Entries, renewed and lapsed counts are unchanged
in both windows. Touches in the current window rose from 116,720 to 226,029, and point R2 is now reached by 119,037
current-window entries. Outputs are in `outputs/rerun_2026-09-21/`, kept apart from the reviewed 19 Sep files.

## Rerun 25 Sep 2026 (v5)

Live pull from `ods.scvepisodeeventstreamfinal` into `_cache_2026-09-25` (the SQL endpoint was slow: 56 minutes for the
events), then `run_all.py --no-pull`. Motor renewal rows 17,362,424, against 9,387,856 on 22 Sep; the pull matches the
stream inventory on every step and matches the table version 7 snapshot the behavioural segmentation read on 24 Sep.

- Unchanged: entries 169,900 current / 167,233 prior, renewed 126,513 / 128,467, the SL04 tie, and every column of the
  22 Sep entries CSV that does not depend on the stream (checked by `tools/validate_v5.py`).
- R2, current window: login only 86,288, call only 24,479, both 37,588, neither 21,545. `reached_R2` is 148,355
  (a login or a call) where the 22 Sep file had 119,037 (the login step alone).
- The table is fuller: an invitation step attaches to 168,809 current-window entries (95,022 on 22 Sep) and touches rise
  from 226,028 to 411,654. Step counts are therefore not comparable with the 22 Sep file.
- R6.F1 'Non-arrival, and time taken to receive' now fires on 124,706 current-window entries (73%). On the framework basis
  ran clean falls from 33,535 to 800 and met a difficulty rises from 69,395 to 132,015. Without R6.F1 they would be 78,330
  and 48,554 (Read me 19). The headline keeps the framework's definition until the data team says what R6.F1 now records.
- 277,133 stream rows carry a placeholder customer key; 114,495 of them are calls with no policy code that cannot be placed.
- About 150,000 rows on the lapse-sequence steps are dated after the stream's end date (Read me 20).
- The re-quote steps (R2.B1.*) now carry a SourceQuoteReference (Requirement M1).

A code review of the v5 changes found no fault in the rename and R2 handling; its fixes to the prose, the placeholder keys,
the failed-login base and the diagnostics are in this version.
